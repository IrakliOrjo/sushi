(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 5933:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9438)), "C:\\Users\\User\\Desktop\\doshi\\sushi\\src\\app\\page.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2911)), "C:\\Users\\User\\Desktop\\doshi\\sushi\\src\\app\\layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["C:\\Users\\User\\Desktop\\doshi\\sushi\\src\\app\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 4965:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1232, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6505, 23))

/***/ }),

/***/ 2087:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 954, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4565))

/***/ }),

/***/ 8356:
/***/ (() => {



/***/ }),

/***/ 4565:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const menuList = [
    {
        id: 1,
        rollType: "Суши",
        rollInfo: [
            {
                id: 1,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 2,
                rollName: "Kabayaki ролл",
                rollWeight: "410 грамм",
                rollReceipt: "Рис, Нори, Авокадо, Огурец, Креветка, Угорь, Спайси соус, Унаги соус",
                rollPrice: "4500 драм"
            },
            {
                id: 3,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 4,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 5,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 6,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            }
        ]
    },
    {
        id: 2,
        rollType: "Классические роллы",
        rollInfo: [
            {
                id: 1,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 2,
                rollName: "Kabayaki ролл",
                rollWeight: "410 грамм",
                rollReceipt: "Рис, Нори, Авокадо, Огурец, Креветка, Угорь, Спайси соус, Унаги соус",
                rollPrice: "4500 драм"
            },
            {
                id: 3,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 4,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 5,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 6,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            }
        ]
    },
    {
        id: 3,
        rollType: "Запеченные роллы",
        rollInfo: [
            {
                id: 1,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 2,
                rollName: "Kabayaki ролл",
                rollWeight: "410 грамм",
                rollReceipt: "Рис, Нори, Авокадо, Огурец, Креветка, Угорь, Спайси соус, Унаги соус",
                rollPrice: "4500 драм"
            },
            {
                id: 3,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 4,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 5,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 6,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            }
        ]
    },
    {
        id: 4,
        rollType: "Авторское меню",
        rollInfo: [
            {
                id: 1,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 2,
                rollName: "Kabayaki ролл",
                rollWeight: "410 грамм",
                rollReceipt: "Рис, Нори, Авокадо, Огурец, Креветка, Угорь, Спайси соус, Унаги соус",
                rollPrice: "4500 драм"
            },
            {
                id: 3,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 4,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 5,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            },
            {
                id: 6,
                rollName: "Фила - Эби ролл",
                rollWeight: "370 грамм",
                rollReceipt: "Рис, Нори, Огурец, Тигровая Креветка, Лосось, Сыр Cremetta",
                rollPrice: "3200 драм"
            }
        ]
    }
];
const Menu = ()=>{
    const [menu, setMenu] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(menuList);
    const [selectedMenu, setSelectedMenu] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Классические роллы");
    const filteredMenu = menu.filter((item)=>{
        return item.rollType === selectedMenu;
    });
    const innerArray = filteredMenu[0].rollInfo;
    console.log(innerArray);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col justify-center mb-[5em] items-center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: "text-[#2d2b2b] text-[2rem] font-[700] mb-11",
                children: "Меню"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex w-full mb-11",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: "flex w-full justify-between",
                    children: menuList.map((item)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: `font-[500] cursor-pointer p-2 ${item.rollType === selectedMenu ? "bg-[#9306061d]" : ""}`,
                            children: item.rollType
                        });
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "grid grid-cols-3 grid-rows-2 gap-4",
                children: innerArray.map((item)=>{
                    console.log("mapped item", item);
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col border-[2px] justify-center items-center border-[black] py-4 px-11 rounded-lg",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "h-[204px] w-[255px] rounded-md border mb-8 border-black"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between text-[.8rem] font-[500] mb-3 w-full text-black",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: item.rollName
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: item.rollWeight
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-[.8rem] mb-6 font-[500]",
                                children: item.rollReceipt
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-[.95rem] mb-6 self-start font-[600]",
                                children: item.rollPrice
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "w-[190px] h-[50px] rounded-3xl text-white bg-red-700",
                                children: "Заказать"
                            })
                        ]
                    });
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menu);


/***/ }),

/***/ 2911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_src_app_layout_js_import_Montserrat_arguments_subsets_latin_variableName_montserrat___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5733);
/* harmony import */ var next_font_google_target_css_path_src_app_layout_js_import_Montserrat_arguments_subsets_latin_variableName_montserrat___WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_app_layout_js_import_Montserrat_arguments_subsets_latin_variableName_montserrat___WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5023);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_globals_css__WEBPACK_IMPORTED_MODULE_1__);



const metadata = {
    title: "Create Next App",
    description: "Generated by create next app"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
            className: (next_font_google_target_css_path_src_app_layout_js_import_Montserrat_arguments_subsets_latin_variableName_montserrat___WEBPACK_IMPORTED_MODULE_2___default().className),
            children: children
        })
    });
}


/***/ }),

/***/ 9438:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(5124);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/app/components/Header.js



const Header = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between mb-[6em]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: "LOGO"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "flex gap-x-6 font-[600]",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "#about",
                            children: "О Нас"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "#menu",
                            children: "Меню"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "#delivery",
                            children: "Доставка"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "#reviews",
                            children: "Отзывы"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "#contact",
                            children: "Контакты"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Header = (Header);

;// CONCATENATED MODULE: ./src/app/components/Banner.js



const Banner = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex gap-4 mb-20",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col basis-[50%] max-w-[38em] ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "font-[700] text-[2.5rem] text-[#2d2b2b] mb-6",
                        children: "Доставка Японской кухни по Еревану "
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "max-w-[29em] mb-6 tracking-wide",
                        children: "Суши и роллы из свежих морепродуктов от лучших шеф-поваров Северной столицы"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "max-w-[27em] mb-14 tracking-wide",
                        children: "Сделайте заказ от 1 000 ₽  и получите набор \xabСуши Мастер\xbb в подарок"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "bg-red-800 text-white font-[700] flex justify-center items-center    w-[260px] h-[71px] rounded-full",
                        children: "Заказать"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "basis-[50%] ",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    className: "rounded-[3em] w-[550px] h-[400px]",
                    src: "/shushi1.png",
                    width: 508,
                    height: 400
                })
            })
        ]
    });
};
/* harmony default export */ const components_Banner = (Banner);

;// CONCATENATED MODULE: ./src/app/components/Doshi.js


const doshiInfo = [
    {
        id: 1,
        photo: "",
        text: `Повара с опытом от 10 лет`
    },
    {
        id: 2,
        photo: "",
        text: `Свежие морепродукты`
    },
    {
        id: 3,
        photo: "",
        text: `Круглосуточная доставка`
    },
    {
        id: 4,
        photo: "",
        text: `Бесплатная доставка от 5000 драм`
    }
];
const Doshi = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col mb-14",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "font-[700] text-[#2d2b2b] mx-auto text-[2rem] mb-14",
                children: "Doshi Sushi - это"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex",
                children: doshiInfo.map((item)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col mx-auto text-center justify-center items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "bg-gray-400 w-[50px] h-[50px] rounded-full mb-6"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-[500] max-w-[11.4em]",
                                children: item.text
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const components_Doshi = (Doshi);

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./src/app/components/Menu.js

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\User\Desktop\doshi\sushi\src\app\components\Menu.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Menu = (__default__);
;// CONCATENATED MODULE: ./src/app/components/Delivery.js


const delivery = [
    {
        id: 1,
        info: "Доставим ваш заказ в любое время суток"
    },
    {
        id: 2,
        info: "Доставим ваш заказ в любое время суток"
    },
    {
        id: 3,
        info: "Доставим ваш заказ в любое время суток"
    },
    {
        id: 4,
        info: "Доставим ваш заказ в любое время суток"
    }
];
const Delivery = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col mb-[10em]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "font-[700] text-[#2d2b2b] mx-auto text-[2rem] mb-14",
                children: "Доставка и оплата"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex",
                children: delivery.map((item)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col mx-auto text-center justify-center items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "bg-gray-400 w-[50px] h-[50px] rounded-full mb-6"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-[500] max-w-[11.4em]",
                                children: item.info
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const components_Delivery = (Delivery);

;// CONCATENATED MODULE: ./src/app/components/About.js


const About = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex gap-24 justify-between mb-[5em]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-[508px] basis-[50%] h-[428px] bg-slate-500"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "basis-[50%] px-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-[36px] mb-11 font-[700] text-black",
                        children: "О Нас"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "max-w-[28em] leading-8 ",
                        children: [
                            "Doshi Sushi был основан в январе 2023 года и стал самым популярным рестораном японской кухни уже через 3 месяцa.",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            "Наши суши и роллы приготовлены из лучших и свежайших морепродуктов. Концепция Doshi Sushi позволяет сохранять приемлемые цены при высочайшем, премиум качестве, в отличие от ресторанов высокой ценовой категории."
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_About = (About);

;// CONCATENATED MODULE: ./src/app/components/Reviews.js


const reviews = [
    {
        id: 1,
        name: "Александра М.",
        comment: "Суши на высшем уровне, еще нигде не ела таких! Заказываю только здесь."
    },
    {
        id: 2,
        name: "Дмитрий С..",
        comment: "Суши на высшем уровне, еще нигде не ела таких! Заказываю только здесь."
    },
    {
        id: 3,
        name: "Алёна Н..",
        comment: "Суши на высшем уровне, еще нигде не ела таких! Заказываю только здесь."
    }
];
const Reviews = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid grid-cols-3 gap-4 mb-11",
        children: reviews.map((item)=>{
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col text-white p-11   min-h-[378px] min-w-[321px] rounded-2xl bg-slate-500 ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-[1.5rem] font-bold mb-6",
                        children: item.name
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-[.9rem] max-w-[14em]",
                        children: item.comment
                    })
                ]
            });
        })
    });
};
/* harmony default export */ const components_Reviews = (Reviews);

;// CONCATENATED MODULE: ./src/app/components/Contact.js



const Contact = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col justify-center items-center mb-[7em]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-[1.5rem] font-bold mb-6",
                children: "Контакты"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: "/image1.png",
                width: 1036,
                height: 430,
                className: "mb-8"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid grid-cols-4 gap-8",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-[1.2rem] font-semibold mb-4",
                                children: "Адрес"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Ереван, ул. Бахрамян"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-[1.2rem] font-semibold mb-4",
                                children: "Часы работы"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Пн-Вс с 00:00 до 00:00"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-[1.2rem] font-semibold mb-4",
                                children: "Телефон"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "+ 7 (812) 999-00-09"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-[1.2rem] font-semibold mb-4",
                                children: "E-mail"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "doshisushi@mail.ru"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Contact = (Contact);

;// CONCATENATED MODULE: ./src/app/components/Footer.js



const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col justify-center items-center mb-[3em]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-[1036px] border-[1px] mb-8 border-black"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between w-full px-20",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "",
                        children: "ЛОГО"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "flex self-end  gap-x-6 font-[600]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "#about",
                                    children: "О Нас"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "#menu",
                                    children: "Меню"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "#delivery",
                                    children: "Доставка"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "#reviews",
                                    children: "Отзывы"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "#contact",
                                    children: "Контакты"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Footer = (Footer);

;// CONCATENATED MODULE: ./src/app/page.js











function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: "bg-white flex flex-col px-[12em] py-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Banner, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Doshi, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Menu, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Delivery, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_About, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Reviews, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Contact, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {})
        ]
    });
}


/***/ }),

/***/ 3881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"16x16"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 5023:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,707], () => (__webpack_exec__(5933)));
module.exports = __webpack_exports__;

})();